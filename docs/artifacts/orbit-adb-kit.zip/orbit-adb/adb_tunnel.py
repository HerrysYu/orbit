#!/usr/bin/env python3
"""Local ADB TCP tunnels and encrypted notifications for Orbit ADB Relay v1."""

from __future__ import annotations

import argparse
import asyncio
import base64
import contextlib
import fcntl
import ipaddress
import json
import os
import shlex
import signal
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl, urlsplit

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from websockets.asyncio.client import connect
from websockets.exceptions import ConnectionClosed, InvalidStatus


HEADER_SIZE = 5
MAX_FRAME_SIZE = 65536
MAX_DATA_SIZE = 32768
MAX_CHANNELS = 8
PEER_CLOSE_DRAIN_TIMEOUT = 2.0
OPEN = 1
DATA = 2
CLOSE = 3
OPEN_OK = 4
OPEN_FAIL = 5
NOTIFY = 6
NOTIFY_ACK = 7
RELAY_NOTIFY_INFO = b"orbit-adb-notif-v1"
LOG_LIMIT_BYTES = 1024 * 1024


class CodeError(ValueError):
    """The supplied connection code is malformed or unsafe."""


@dataclass(frozen=True)
class ConnectionCode:
    relay: str
    phone: str
    token: str = field(repr=False)
    notif_key: bytes = field(repr=False)
    aad: bytes = field(repr=False)

    @property
    def client_url(self) -> str:
        return f"{self.relay}/v1/tunnel/{self.phone}/client"


@dataclass(frozen=True)
class Frame:
    kind: int
    channel: int
    payload: bytes


def _derive_notif_key(token: str) -> bytes:
    return HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=bytes(32),
        info=RELAY_NOTIFY_INFO,
    ).derive(token.encode("utf-8"))


def _validate_relay(relay: str) -> str:
    try:
        parsed = urlsplit(relay)
        host = parsed.hostname
        port = parsed.port
    except ValueError as exc:
        raise CodeError("Relay 地址格式无效") from exc
    scheme = parsed.scheme.lower()
    if scheme not in ("ws", "wss") or not host:
        raise CodeError("Relay 地址必须使用 ws:// 或 wss://")
    if parsed.username is not None or parsed.password is not None:
        raise CodeError("Relay 地址不能包含用户名或密码")
    if parsed.path or parsed.query or parsed.fragment:
        raise CodeError("Relay 地址只能包含主机和可选端口")
    if port is not None and not 1 <= port <= 65535:
        raise CodeError("Relay 端口无效")
    if scheme == "ws":
        if host != "localhost":
            try:
                address = ipaddress.ip_address(host)
            except ValueError as exc:
                raise CodeError("明文 ws:// 仅允许本机或私有 IPv4 地址") from exc
            private_networks = (
                ipaddress.ip_network("10.0.0.0/8"),
                ipaddress.ip_network("172.16.0.0/12"),
                ipaddress.ip_network("192.168.0.0/16"),
            )
            if not isinstance(address, ipaddress.IPv4Address) or not (
                address == ipaddress.ip_address("127.0.0.1")
                or any(address in network for network in private_networks)
            ):
                raise CodeError("明文 ws:// 仅允许本机或私有 IPv4 地址")
    return f"{scheme}://{parsed.netloc}"


def parse_code(value: str) -> ConnectionCode:
    """Parse a strict orbit-adb://v1 code and derive the notification key."""
    if not isinstance(value, str) or not value or value.strip() != value:
        raise CodeError("连接码格式无效")
    try:
        outer = urlsplit(value)
        fields = parse_qsl(
            outer.query,
            keep_blank_values=True,
            strict_parsing=True,
            max_num_fields=4,
            encoding="utf-8",
            errors="strict",
        )
    except (ValueError, UnicodeError) as exc:
        raise CodeError("连接码格式无效") from exc
    if outer.scheme != "orbit-adb" or outer.netloc != "v1" or outer.path or outer.fragment:
        raise CodeError("连接码格式无效")
    params: dict[str, str] = {}
    for key, val in fields:
        if key not in {"relay", "phone", "token"}:
            raise CodeError("连接码包含未知参数")
        if key in params:
            raise CodeError("连接码参数重复")
        params[key] = val
    if set(params) != {"relay", "phone", "token"} or any(not v for v in params.values()):
        raise CodeError("连接码缺少必要参数")
    phone = params["phone"]
    if len(phone) != 32 or any(c not in "0123456789abcdef" for c in phone):
        raise CodeError("phoneId 格式无效")
    token = params["token"]
    if not (32 <= len(token) <= 128) or any(c not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-" for c in token):
        raise CodeError("连接令牌格式无效")
    try:
        decoded = base64.urlsafe_b64decode(token + "=" * (-len(token) % 4))
    except (ValueError, TypeError) as exc:
        raise CodeError("连接令牌格式无效") from exc
    if len(decoded) != 32 or base64.urlsafe_b64encode(decoded).rstrip(b"=").decode("ascii") != token:
        raise CodeError("连接令牌格式无效")
    relay = _validate_relay(params["relay"])
    return ConnectionCode(
        relay=relay,
        phone=phone,
        token=token,
        notif_key=_derive_notif_key(token),
        aad=f"orbit-adb-notif-v1|{phone}".encode("utf-8"),
    )


def encode_frame(kind: int, channel: int, payload: bytes = b"") -> bytes:
    """Encode type:u8 | channel:u32 big-endian | payload."""
    if not isinstance(kind, int) or not 0 <= kind <= 255:
        raise ValueError("frame type must fit in one byte")
    if not isinstance(channel, int) or not 0 <= channel <= 0xFFFFFFFF:
        raise ValueError("channel must fit in four bytes")
    if not isinstance(payload, bytes):
        raise TypeError("frame payload must be bytes")
    if HEADER_SIZE + len(payload) > MAX_FRAME_SIZE:
        raise ValueError("frame is larger than the protocol limit")
    if kind == DATA and not 1 <= len(payload) <= MAX_DATA_SIZE:
        raise ValueError("DATA payload must contain 1 to 32768 bytes")
    return bytes((kind,)) + channel.to_bytes(4, "big") + payload


def decode_frame(raw: bytes) -> Frame:
    """Decode a binary frame, rejecting truncated or oversized input."""
    if not isinstance(raw, bytes) or len(raw) < HEADER_SIZE:
        raise ValueError("truncated frame")
    if len(raw) > MAX_FRAME_SIZE:
        raise ValueError("frame is larger than the protocol limit")
    kind = raw[0]
    channel = int.from_bytes(raw[1:5], "big")
    payload = raw[5:]
    if kind == DATA and not 1 <= len(payload) <= MAX_DATA_SIZE:
        raise ValueError("invalid DATA payload size")
    return Frame(kind, channel, payload)


def encode_ack(seq: int) -> bytes:
    """Encode NOTIFY_ACK for channel zero."""
    if not isinstance(seq, int) or isinstance(seq, bool) or not 0 <= seq <= 0xFFFFFFFFFFFFFFFF:
        raise ValueError("notification sequence must fit in eight bytes")
    return encode_frame(NOTIFY_ACK, 0, seq.to_bytes(8, "big"))


def _atomic_write(path: Path, data: bytes, mode: int = 0o600) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(path.parent, 0o700)
    temp = path.with_name(f".{path.name}.{os.getpid()}.{time.time_ns()}.tmp")
    fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    try:
        os.fchmod(fd, mode)
        with os.fdopen(fd, "wb", closefd=False) as stream:
            stream.write(data)
            stream.flush()
            os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(temp, path)
    os.chmod(path, mode)
    dir_fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(dir_fd)
    finally:
        os.close(dir_fd)


class StateDir:
    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path).expanduser() if path else Path.home() / ".orbit-adb"

    def ensure(self) -> None:
        self.path.mkdir(mode=0o700, parents=True, exist_ok=True)
        os.chmod(self.path, 0o700)

    @property
    def code_path(self) -> Path:
        return self.path / "code"

    @property
    def pid_path(self) -> Path:
        return self.path / "tunnel.pid"

    @property
    def status_path(self) -> Path:
        return self.path / "status.json"

    @property
    def notifications_path(self) -> Path:
        return self.path / "notifications.jsonl"

    @property
    def read_path(self) -> Path:
        return self.path / "notifications.read"

    @property
    def log_path(self) -> Path:
        return self.path / "tunnel.log"

    def save_code(self, code: str) -> None:
        self.ensure()
        _atomic_write(self.code_path, (code + "\n").encode("utf-8"))

    def read_code(self) -> str:
        self.ensure()
        if not self.code_path.exists():
            raise FileNotFoundError("未找到连接码；请传入 --code 或设置 ORBIT_ADB_CODE")
        os.chmod(self.code_path, 0o600)
        return self.code_path.read_text(encoding="utf-8").rstrip("\r\n")

    def acquire_pid_lock(self):
        self.ensure()
        handle = open(self.pid_path, "a+b")
        os.chmod(self.pid_path, 0o600)
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            handle.close()
            raise RuntimeError("该状态目录已有隧道实例运行") from None
        identity = _process_identity(os.getpid())
        record = {
            "pid": os.getpid(),
            "started": identity[0] if identity else None,
            "state_dir": str(self.path.resolve()),
        }
        handle.seek(0)
        handle.truncate()
        handle.write(json.dumps(record, separators=(",", ":")).encode("utf-8"))
        handle.flush()
        os.fsync(handle.fileno())
        return handle

    async def write_status(self, status: dict[str, Any]) -> None:
        encoded = json.dumps(status, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8") + b"\n"
        await asyncio.to_thread(_atomic_write, self.status_path, encoded)

    def read_status(self) -> dict[str, Any]:
        self.ensure()
        try:
            value = json.loads(self.status_path.read_text(encoding="utf-8"))
            return value if isinstance(value, dict) else {"state": "unknown"}
        except FileNotFoundError:
            return {"state": "stopped"}
        except (OSError, UnicodeError, json.JSONDecodeError):
            return {"state": "unavailable"}

    async def log(self, message: str) -> None:
        await asyncio.to_thread(self._append_log, message)

    def _append_log(self, message: str) -> None:
        self.ensure()
        if self.log_path.exists() and self.log_path.stat().st_size > LOG_LIMIT_BYTES:
            old = self.log_path.read_bytes()
            _atomic_write(self.log_path, old[-LOG_LIMIT_BYTES // 2 :])
        line = f"{time.strftime('%Y-%m-%dT%H:%M:%S%z')} {message}\n".encode("utf-8")
        fd = os.open(self.log_path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        try:
            os.fchmod(fd, 0o600)
            os.write(fd, line)
            os.fsync(fd)
        finally:
            os.close(fd)

    def _seq_path(self, phone_id: str) -> Path:
        return self.path / f"notify.seq.{phone_id}"

    def append_notification(self, phone_id: str, notification: dict[str, Any]) -> tuple[bool, int]:
        """Append/fsync a notification and persist its high-water mark for this phone."""
        self.ensure()
        seq = notification.get("seq")
        if not isinstance(seq, int) or isinstance(seq, bool) or seq < 0:
            raise ValueError("invalid notification sequence")
        high_path = self._seq_path(phone_id)
        try:
            high = int(high_path.read_text(encoding="ascii").strip())
        except FileNotFoundError:
            high = 0
        except (ValueError, OSError, UnicodeError):
            high = 0

        rows: list[dict[str, Any]] = []
        try:
            with self.notifications_path.open("r", encoding="utf-8") as stream:
                for line in stream:
                    try:
                        item = json.loads(line)
                        if isinstance(item, dict):
                            rows.append(item)
                    except json.JSONDecodeError:
                        continue
        except FileNotFoundError:
            pass

        journal_high = max(
            (
                item.get("seq", 0)
                for item in rows
                if item.get("phoneId") == phone_id
                and isinstance(item.get("seq"), int)
                and not isinstance(item.get("seq"), bool)
            ),
            default=0,
        )
        high = max(high, journal_high)
        if seq <= high:
            if not high_path.exists() or high > 0:
                _atomic_write(high_path, f"{high}\n".encode("ascii"))
            return False, high

        last_id = max((int(item.get("_id", 0)) for item in rows if str(item.get("_id", "0")).isdigit()), default=0)
        record = dict(notification)
        record["phoneId"] = phone_id
        record["_id"] = last_id + 1
        encoded = json.dumps(record, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8") + b"\n"
        fd = os.open(self.notifications_path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "ab", closefd=False) as stream:
                stream.write(encoded)
                stream.flush()
                os.fsync(fd)
        finally:
            os.close(fd)
        _atomic_write(high_path, f"{seq}\n".encode("ascii"))

        if len(rows) + 1 > 4000:
            keep = (rows + [record])[-2000:]
            compact = b"".join(
                json.dumps(item, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8") + b"\n"
                for item in keep
            )
            _atomic_write(self.notifications_path, compact)
        return True, seq

    def read_notifications(self, all_items: bool, limit: int | None) -> tuple[list[dict[str, Any]], int]:
        self.ensure()
        try:
            cursor = int(self.read_path.read_text(encoding="ascii").strip())
        except FileNotFoundError:
            cursor = 0
        except (ValueError, OSError, UnicodeError):
            cursor = 0
        rows: list[dict[str, Any]] = []
        try:
            with self.notifications_path.open("r", encoding="utf-8") as stream:
                for line in stream:
                    try:
                        item = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if isinstance(item, dict) and isinstance(item.get("_id"), int):
                        if all_items or item["_id"] > cursor:
                            rows.append(item)
        except FileNotFoundError:
            pass
        if limit is not None:
            rows = rows[:limit]
        return rows, cursor

    def advance_read_cursor(self, cursor: int) -> None:
        try:
            previous = int(self.read_path.read_text(encoding="ascii").strip())
        except (FileNotFoundError, OSError, ValueError, UnicodeError):
            previous = 0
        _atomic_write(self.read_path, f"{max(previous, cursor)}\n".encode("ascii"))


def _process_identity(pid: int) -> tuple[str, str] | None:
    try:
        started = subprocess.run(
            ["ps", "-p", str(pid), "-o", "lstart="],
            check=False,
            capture_output=True,
            text=True,
            timeout=2,
        ).stdout.strip()
        command = subprocess.run(
            ["ps", "-ww", "-p", str(pid), "-o", "command="],
            check=False,
            capture_output=True,
            text=True,
            timeout=2,
        ).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return None
    if not started or "adb_tunnel.py" not in command or "run" not in command:
        return None
    return started, command


def _signal_tunnel(state: StateDir) -> tuple[bool, str]:
    state.ensure()
    lock = None
    try:
        record = json.loads(state.pid_path.read_text(encoding="utf-8"))
        pid = record.get("pid")
        started = record.get("started")
        recorded_state_dir = record.get("state_dir")
    except FileNotFoundError:
        return False, "没有运行中的隧道实例"
    except (OSError, UnicodeError, json.JSONDecodeError, AttributeError):
        return False, "pid 文件无效，未发送停止信号"
    if (
        not isinstance(pid, int)
        or pid <= 1
        or pid == os.getpid()
        or not isinstance(started, str)
        or recorded_state_dir != str(state.path.resolve())
    ):
        return False, "无法确认隧道进程身份，未发送停止信号"
    try:
        lock = open(state.pid_path, "a+b")
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            pass
        else:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
            return False, "没有运行中的隧道实例"
        current = _process_identity(pid)
        if current is None or current[0] != started:
            return False, "pid 已失效或已被其他进程使用，未发送停止信号"
        os.kill(pid, signal.SIGTERM)
        return True, "已向当前隧道实例发送停止信号"
    except ProcessLookupError:
        return False, "没有运行中的隧道实例"
    except PermissionError:
        return False, "没有权限停止该隧道实例"
    except OSError:
        return False, "无法停止隧道实例"
    finally:
        if lock is not None:
            lock.close()


@dataclass
class Channel:
    number: int
    kind: str
    reader: asyncio.StreamReader
    writer: asyncio.StreamWriter
    opened: asyncio.Future[bool]
    incoming: asyncio.Queue[bytes | None]
    write_task: asyncio.Task[None] | None = None
    read_task: asyncio.Task[None] | None = None
    close_task: asyncio.Task[None] | None = None
    is_open: bool = False
    closing: bool = False


class TunnelSession:
    def __init__(self, ws, state: StateDir, code: ConnectionCode, app: "TunnelApp") -> None:
        self.ws = ws
        self.state = state
        self.code = code
        self.app = app
        self.send_lock = asyncio.Lock()
        self.channels: dict[int, Channel] = {}
        self.next_channel = 1
        self.closed = False

    async def send(self, frame: bytes) -> None:
        async with self.send_lock:
            await self.ws.send(frame)

    async def open_local(self, kind: str, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        if self.closed or len(self.channels) >= MAX_CHANNELS or self.next_channel > 0xFFFFFFFF:
            writer.close()
            with contextlib.suppress(Exception):
                await writer.wait_closed()
            return
        number = self.next_channel
        self.next_channel += 1
        loop = asyncio.get_running_loop()
        channel = Channel(
            number=number,
            kind=kind,
            reader=reader,
            writer=writer,
            opened=loop.create_future(),
            incoming=asyncio.Queue(maxsize=64),
        )
        channel.write_task = asyncio.create_task(self._write_pump(channel))
        self.channels[number] = channel
        try:
            await self.send(encode_frame(OPEN, number, kind.encode("ascii")))
            accepted = await asyncio.wait_for(asyncio.shield(channel.opened), timeout=6.0)
            if not accepted or channel.closing:
                return
            channel.read_task = asyncio.create_task(self._read_pump(channel))
        except TimeoutError:
            await self.app.say("等待手机打开 ADB 通道超时。")
            await self._close_channel(number, send_close=True)
        except (ConnectionClosed, OSError, RuntimeError):
            await self._close_channel(number, send_close=False)

    async def handle(self, frame: Frame) -> None:
        if frame.kind == NOTIFY:
            if frame.channel == 0:
                await self.app.handle_notification(frame.payload, self)
            return
        if frame.kind == OPEN_OK:
            channel = self.channels.get(frame.channel)
            if channel is not None and not channel.opened.done():
                channel.is_open = True
                channel.opened.set_result(True)
            return
        if frame.kind == OPEN_FAIL:
            channel = self.channels.get(frame.channel)
            if channel is not None:
                if not channel.opened.done():
                    channel.opened.set_result(False)
                reason = frame.payload.decode("utf-8", "replace")
                await self.app.open_fail(channel.kind, reason)
                await self._close_channel(frame.channel, send_close=False)
            return
        if frame.kind == DATA:
            channel = self.channels.get(frame.channel)
            if channel is None or not channel.is_open or channel.closing:
                with contextlib.suppress(ConnectionClosed, OSError):
                    await self.send(encode_frame(CLOSE, frame.channel))
                if channel is not None and not channel.closing:
                    await self._close_channel(frame.channel, send_close=False)
                return
            await channel.incoming.put(frame.payload)
            return
        if frame.kind == CLOSE:
            channel = self.channels.get(frame.channel)
            if channel is not None and channel.close_task is None:
                channel.closing = True
                channel.close_task = asyncio.create_task(self._finish_peer_close(channel))
            return
        # Unknown frame types are deliberately ignored for forward compatibility.

    async def _read_pump(self, channel: Channel) -> None:
        try:
            while not channel.closing:
                payload = await channel.reader.read(MAX_DATA_SIZE)
                if not payload:
                    break
                await self.send(encode_frame(DATA, channel.number, payload))
        except (ConnectionClosed, OSError, RuntimeError):
            pass
        finally:
            await self._close_channel(channel.number, send_close=True)

    async def _write_pump(self, channel: Channel) -> None:
        try:
            while True:
                payload = await channel.incoming.get()
                if payload is None:
                    return
                channel.writer.write(payload)
                await channel.writer.drain()
        except (ConnectionClosed, OSError, RuntimeError):
            await self._close_channel(channel.number, send_close=True)

    async def _finish_peer_close(self, channel: Channel) -> None:
        current = asyncio.current_task()
        if channel.read_task is not None and channel.read_task is not current and not channel.read_task.done():
            channel.read_task.cancel()

        async def drain_received_data() -> None:
            await channel.incoming.put(None)
            if channel.write_task is not None:
                await channel.write_task

        try:
            await asyncio.wait_for(drain_received_data(), timeout=PEER_CLOSE_DRAIN_TIMEOUT)
        except TimeoutError:
            pass
        finally:
            await self._close_channel(channel.number, send_close=False, immediate=True)

    async def _close_channel(self, number: int, send_close: bool, *, immediate: bool = False) -> None:
        channel = self.channels.get(number)
        if channel is None or (channel.closing and not immediate):
            return
        channel.closing = True
        self.channels.pop(number, None)
        if not channel.opened.done():
            channel.opened.set_result(False)
        current = asyncio.current_task()
        if channel.close_task is not None and channel.close_task is not current and not channel.close_task.done():
            channel.close_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await channel.close_task
        if send_close and not self.closed:
            with contextlib.suppress(ConnectionClosed, OSError, RuntimeError):
                await self.send(encode_frame(CLOSE, number))
        for task in (channel.read_task, channel.write_task):
            if task is not None and task is not current and not task.done():
                task.cancel()
        pending = [
            task
            for task in (channel.read_task, channel.write_task)
            if task is not None and task is not current and not task.done()
        ]
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        channel.writer.close()
        with contextlib.suppress(Exception):
            await channel.writer.wait_closed()
        await self.app.update_status()

    async def close_all(self) -> None:
        self.closed = True
        for number in list(self.channels):
            await self._close_channel(number, send_close=False, immediate=True)


class TunnelApp:
    def __init__(
        self,
        state: StateDir,
        code: ConnectionCode,
        *,
        no_auto_connect: bool = False,
        on_notify: list[str] | None = None,
    ) -> None:
        self.state = state
        self.code = code
        self.no_auto_connect = no_auto_connect
        self.on_notify = on_notify or []
        self.stop_event = asyncio.Event()
        self.session: TunnelSession | None = None
        self.hook_tasks: set[asyncio.Task[None]] = set()
        self.background_tasks: set[asyncio.Task[Any]] = set()
        self.status: dict[str, Any] = {
            "state": "starting",
            "relay": code.relay,
            "phoneId": code.phone,
            "connected": False,
            "channels": 0,
            "notificationForwarding": "waiting",
            "updatedAt": int(time.time()),
        }
        self.servers: list[asyncio.AbstractServer] = []

    async def say(self, message: str) -> None:
        print(message, file=sys.stderr, flush=True)

    async def update_status(self, **changes: Any) -> None:
        self.status.update(changes)
        self.status["channels"] = len(self.session.channels) if self.session else 0
        if not self.status.get("connected"):
            self.status["notificationForwarding"] = "waiting"
        elif self.status.get("notificationForwarding") == "waiting":
            self.status["notificationForwarding"] = "connected"
        self.status["updatedAt"] = int(time.time())
        await self.state.write_status(self.status)

    async def local_connection(self, kind: str, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        session = self.session
        if session is None or session.closed:
            writer.close()
            with contextlib.suppress(Exception):
                await writer.wait_closed()
            return
        await session.open_local(kind, reader, writer)
        await self.update_status()

    async def open_fail(self, kind: str, reason: str) -> None:
        if reason == "no_port":
            message = (
                "手机上没打开『无线调试 → 使用配对码配对』窗口"
                if kind == "pair"
                else "手机没打开无线调试，或 App 没找到端口"
            )
        elif reason == "connect_failed":
            message = "手机连接本机 ADB 超时。"
        elif reason == "too_many":
            message = "手机通道已满。"
        elif reason == "bad_target":
            message = "手机拒绝了该 ADB 目标。"
        else:
            message = "手机未能打开 ADB 通道。"
        await self.say(message)

    async def handle_notification(self, encrypted: bytes, session: TunnelSession) -> None:
        if len(encrypted) < 12 + 16:
            await self.state.log("notification frame was too short")
            return
        nonce, ciphertext = encrypted[:12], encrypted[12:]
        try:
            plaintext = AESGCM(self.code.notif_key).decrypt(nonce, ciphertext, self.code.aad)
        except (InvalidTag, ValueError):
            await self.state.log("notification could not be decrypted")
            return
        try:
            value = json.loads(plaintext)
            if not isinstance(value, dict):
                raise ValueError
            seq = value.get("seq")
            if not isinstance(seq, int) or isinstance(seq, bool) or not 0 <= seq <= 0xFFFFFFFFFFFFFFFF:
                raise ValueError
        except (ValueError, UnicodeError, json.JSONDecodeError):
            await self.state.log("notification payload was invalid")
            return
        try:
            added, high = await asyncio.to_thread(self.state.append_notification, self.code.phone, value)
        except (OSError, ValueError, TypeError):
            await self.state.log("notification could not be saved")
            return
        try:
            await session.send(encode_ack(high))
        except (ConnectionClosed, OSError, RuntimeError):
            return
        self.status["lastNotificationSeq"] = high
        self.status["lastNotificationAt"] = int(time.time())
        self.status["notificationForwarding"] = "received"
        await self.update_status()
        if added and self.on_notify:
            task = asyncio.create_task(self.run_hook(value))
            self.hook_tasks.add(task)
            task.add_done_callback(self.hook_tasks.discard)

    async def run_hook(self, notification: dict[str, Any]) -> None:
        if not self.on_notify:
            return
        process = None
        try:
            process = await asyncio.create_subprocess_exec(
                *self.on_notify,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            payload = json.dumps(notification, ensure_ascii=False, separators=(",", ":")).encode("utf-8") + b"\n"
            await asyncio.wait_for(process.communicate(payload), timeout=30)
            if process.returncode:
                await self.state.log("notification hook exited with an error")
        except TimeoutError:
            if process is not None:
                with contextlib.suppress(ProcessLookupError):
                    process.kill()
                with contextlib.suppress(Exception):
                    await process.wait()
            await self.state.log("notification hook timed out")
        except asyncio.CancelledError:
            if process is not None:
                with contextlib.suppress(ProcessLookupError):
                    process.kill()
                with contextlib.suppress(Exception):
                    await process.wait()
            raise
        except (OSError, ValueError):
            await self.state.log("notification hook could not be started")

    async def auto_connect(self) -> None:
        if self.no_auto_connect:
            return
        process = None
        try:
            process = await asyncio.create_subprocess_exec(
                "adb",
                "connect",
                "127.0.0.1:15555",
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await asyncio.wait_for(process.wait(), timeout=10)
        except TimeoutError:
            if process is not None:
                with contextlib.suppress(ProcessLookupError):
                    process.kill()
                with contextlib.suppress(Exception):
                    await process.wait()
            await self.state.log("adb connect timed out")
        except asyncio.CancelledError:
            if process is not None and process.returncode is None:
                with contextlib.suppress(ProcessLookupError):
                    process.kill()
                with contextlib.suppress(Exception):
                    await process.wait()
            raise
        except OSError:
            await self.state.log("adb connect could not be started")

    async def _receive(self, ws, session: TunnelSession) -> int | None:
        try:
            while not self.stop_event.is_set():
                message = await ws.recv()
                if isinstance(message, str):
                    continue
                try:
                    frame = decode_frame(message)
                except ValueError:
                    await self.state.log("invalid binary frame ignored")
                    continue
                await session.handle(frame)
        except ConnectionClosed as exc:
            return getattr(exc, "code", None) or ws.close_code
        except (OSError, RuntimeError):
            return ws.close_code
        return ws.close_code

    async def _connected(self, ws) -> int | None:
        session = TunnelSession(ws, self.state, self.code, self)
        self.session = session
        await self.update_status(state="connected", connected=True, lastCloseCode=None, lastError=None)
        await self.state.log("relay websocket connected")
        if not self.no_auto_connect:
            task = asyncio.create_task(self.auto_connect())
            self.background_tasks.add(task)
            task.add_done_callback(self.background_tasks.discard)
        receiver = asyncio.create_task(self._receive(ws, session))
        stopper = asyncio.create_task(self.stop_event.wait())
        try:
            done, _ = await asyncio.wait((receiver, stopper), return_when=asyncio.FIRST_COMPLETED)
            if stopper in done:
                with contextlib.suppress(Exception):
                    await ws.close(code=1000, reason="stopping")
                receiver.cancel()
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await receiver
                return ws.close_code
            return await receiver
        finally:
            stopper.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await stopper
            await session.close_all()
            self.session = None
            await self.update_status(state="reconnecting", connected=False)
            await self.state.log("relay websocket disconnected")

    async def _sleep_or_stop(self, delay: float) -> None:
        try:
            await asyncio.wait_for(self.stop_event.wait(), timeout=delay)
        except TimeoutError:
            pass

    async def relay_loop(self) -> int:
        retry = 1.0
        while not self.stop_event.is_set():
            close_code: int | None = None
            try:
                options: dict[str, Any] = {
                    "additional_headers": {"Authorization": f"Bearer {self.code.token}"},
                    "open_timeout": 10,
                    "close_timeout": 3,
                    "ping_interval": 20,
                    "ping_timeout": 20,
                    "max_size": MAX_FRAME_SIZE,
                    "compression": None,
                }
                if self.code.relay.startswith("ws://"):
                    options["proxy"] = None
                async with connect(self.code.client_url, **options) as ws:
                    retry = 1.0
                    close_code = await self._connected(ws)
            except InvalidStatus as exc:
                status = exc.response.status_code
                if status == 401:
                    await self.say("连接码无效、已吊销或已过期")
                    await self.state.log("relay rejected authorization (HTTP 401)")
                    await self.update_status(state="stopped", connected=False, lastError="unauthorized")
                    return 2
                await self.state.log(f"relay handshake failed (HTTP {status})")
                if status in (400, 403):
                    await self.say("Relay 拒绝了连接，请检查连接码和 Relay 配置。")
            except (OSError, TimeoutError, ConnectionClosed, asyncio.TimeoutError) as exc:
                if not self.stop_event.is_set():
                    await self.state.log(f"relay connection failed ({type(exc).__name__})")
            except Exception as exc:
                if not self.stop_event.is_set():
                    await self.state.log(f"relay connection failed ({type(exc).__name__})")

            if self.stop_event.is_set():
                break
            if close_code is not None:
                await self.update_status(lastCloseCode=close_code)
                if close_code == 4000:
                    await self.say("此连接码已在另一进程中使用，当前实例退出。")
                    await self.state.log("relay closed connection as replaced (4000)")
                    await self.update_status(state="stopped", connected=False, lastError="replaced")
                    return 3
                if close_code == 4001:
                    await self.say("连接码无效、已吊销或已过期")
                    await self.state.log("relay closed connection as revoked (4001)")
                    await self.update_status(state="stopped", connected=False, lastError="revoked")
                    return 2
                if close_code == 4008:
                    delay = 60.0
                elif close_code in (4003, 4004):
                    retry = 1.0
                    delay = 1.0
                else:
                    delay = min(30.0, retry)
                    retry = min(30.0, retry * 2)
            else:
                delay = min(30.0, retry)
                retry = min(30.0, retry * 2)
            if delay != 60.0:
                delay = min(30.0, delay * (0.8 + (os.urandom(2)[0] / 255) * 0.4))
            await self.update_status(state="reconnecting", connected=False, retryIn=round(delay, 2))
            await self._sleep_or_stop(delay)
        return 0

    async def run(self) -> int:
        self.state.ensure()
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            with contextlib.suppress(NotImplementedError, RuntimeError):
                loop.add_signal_handler(sig, self.stop_event.set)
        try:
            adb = await asyncio.start_server(
                lambda r, w: self.local_connection("adb", r, w),
                host="127.0.0.1",
                port=15555,
            )
            self.servers.append(adb)
            pair = await asyncio.start_server(
                lambda r, w: self.local_connection("pair", r, w),
                host="127.0.0.1",
                port=15556,
            )
            self.servers.append(pair)
        except OSError as exc:
            for server in self.servers:
                server.close()
                await server.wait_closed()
            self.servers.clear()
            await self.say(f"无法监听本机端口 15555/15556：{exc.strerror or '端口不可用'}")
            await self.update_status(state="stopped", connected=False, lastError="local_bind_failed")
            return 1
        await self.update_status(state="connecting", connected=False, localPorts=[15555, 15556])
        result = await self.relay_loop()
        for server in self.servers:
            server.close()
            await server.wait_closed()
        self.servers.clear()
        for task in list(self.hook_tasks):
            task.cancel()
        if self.hook_tasks:
            await asyncio.gather(*self.hook_tasks, return_exceptions=True)
        for task in list(self.background_tasks):
            task.cancel()
        if self.background_tasks:
            await asyncio.gather(*self.background_tasks, return_exceptions=True)
        await self.update_status(state="stopped", connected=False, channels=0, stoppedAt=int(time.time()))
        for sig in (signal.SIGINT, signal.SIGTERM):
            with contextlib.suppress(NotImplementedError, RuntimeError):
                loop.remove_signal_handler(sig)
        return result


def _resolve_code(args: argparse.Namespace, state: StateDir) -> str:
    code = args.code or os.environ.get("ORBIT_ADB_CODE")
    if not code:
        code = state.read_code()
    return code


async def command_run(args: argparse.Namespace, state: StateDir) -> int:
    try:
        raw_code = _resolve_code(args, state)
        code = parse_code(raw_code)
    except (CodeError, OSError, FileNotFoundError) as exc:
        print(str(exc), file=sys.stderr)
        return 2
    try:
        hook = shlex.split(args.on_notify) if args.on_notify else []
        if args.on_notify and not hook:
            raise ValueError("--on-notify 命令为空")
    except ValueError as exc:
        print(f"--on-notify 参数无效：{exc}", file=sys.stderr)
        return 2
    try:
        pid_handle = state.acquire_pid_lock()
    except (RuntimeError, OSError) as exc:
        print(str(exc), file=sys.stderr)
        return 1
    if args.save_code:
        try:
            state.save_code(raw_code)
        except OSError as exc:
            pid_handle.close()
            print(f"无法保存连接码：{exc.strerror or '写入失败'}", file=sys.stderr)
            return 1
    app = TunnelApp(state, code, no_auto_connect=args.no_auto_connect, on_notify=hook)
    try:
        await app.state.log("tunnel process started")
        await app.say("ADB 隧道已启动，等待 Relay 连接。")
        return await app.run()
    finally:
        pid_handle.close()


def command_notifications(args: argparse.Namespace, state: StateDir) -> int:
    if args.limit is not None and args.limit < 1:
        print("--limit 必须大于 0", file=sys.stderr)
        return 2
    try:
        rows, _ = state.read_notifications(args.all, args.limit)
        for item in rows:
            output = dict(item)
            output.pop("_id", None)
            print(json.dumps(output, ensure_ascii=False, separators=(",", ":")))
        if rows:
            sys.stdout.flush()
            state.advance_read_cursor(rows[-1]["_id"])
    except (OSError, UnicodeError, ValueError) as exc:
        print(f"读取通知失败：{exc}", file=sys.stderr)
        return 1
    return 0


def command_status(state: StateDir) -> int:
    print(json.dumps(state.read_status(), ensure_ascii=False, indent=2, sort_keys=True))
    return 0


def command_stop(state: StateDir) -> int:
    ok, message = _signal_tunnel(state)
    print(message)
    return 0 if ok else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Orbit ADB Relay 隧道客户端")
    subparsers = parser.add_subparsers(dest="command", required=True)

    run = subparsers.add_parser("run", help="运行 ADB 隧道")
    run.add_argument("--code", help="orbit-adb://v1 连接码")
    run.add_argument("--save-code", action="store_true", help="将连接码以 0600 权限保存到状态目录")
    run.add_argument("--state-dir", help="状态目录，默认 ~/.orbit-adb")
    run.add_argument("--no-auto-connect", action="store_true", help="不自动执行 adb connect")
    run.add_argument("--on-notify", help="通知到达后执行的命令；通知 JSON 从 stdin 传入")

    notifications = subparsers.add_parser("notifications", help="读取已保存的通知")
    notifications.add_argument("--all", action="store_true", help="显示所有保留的通知")
    notifications.add_argument("--limit", type=int, help="最多显示条数")
    notifications.add_argument("--state-dir", help="状态目录，默认 ~/.orbit-adb")

    status = subparsers.add_parser("status", help="查看隧道状态")
    status.add_argument("--state-dir", help="状态目录，默认 ~/.orbit-adb")

    stop = subparsers.add_parser("stop", help="停止该状态目录中的隧道实例")
    stop.add_argument("--state-dir", help="状态目录，默认 ~/.orbit-adb")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    state = StateDir(getattr(args, "state_dir", None))
    if args.command == "run":
        return asyncio.run(command_run(args, state))
    if args.command == "notifications":
        return command_notifications(args, state)
    if args.command == "status":
        return command_status(state)
    if args.command == "stop":
        return command_stop(state)
    parser.error("未知命令")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
