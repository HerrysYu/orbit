"""Single-call JSON CLI for the Orbit phone ADB primitives."""

from __future__ import annotations

import argparse
import base64
import contextlib
import json
import math
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, TypeVar

from phone_agent.config.apps import APP_PACKAGES

from . import adb
from .lock import DeviceLock, PhoneCancelled, PhoneNotStarted, opa_home


DEFAULT_SERIAL = "127.0.0.1:15555"
SETTLE_SECONDS = 0.6
SHOT_LIMIT = 50
_PACKAGE_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+$")
_COMPONENT_RE = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z0-9_]+)+)/\S+$")
T = TypeVar("T")


class CliUsageError(Exception):
    pass


class CliArgumentParser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        raise CliUsageError(message)


class DeviceBusy(Exception):
    pass


def _coordinate(raw: str) -> float:
    try:
        value = float(raw)
    except ValueError:
        raise argparse.ArgumentTypeError("坐标必须是 0 到 999 之间的数字") from None
    if not math.isfinite(value) or not 0 <= value <= 999:
        raise argparse.ArgumentTypeError("坐标必须是 0 到 999 之间的数字")
    return value


def _finite_seconds(raw: str) -> float:
    try:
        value = float(raw)
    except ValueError:
        raise argparse.ArgumentTypeError("等待秒数必须是 0 到 10 之间的数字") from None
    if not math.isfinite(value) or not 0 <= value <= 10:
        raise argparse.ArgumentTypeError("等待秒数必须是 0 到 10 之间的数字")
    return value


def build_parser() -> CliArgumentParser:
    parser = CliArgumentParser(prog="python -m orbit_phone.cli", description="对一台 Android 手机执行单次 ADB 操作并输出 JSON。")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("status", help="读取设备状态")

    observe = sub.add_parser("observe", help="截图并读取设备状态、默认包含结构树")
    observe.add_argument("--no-tree", action="store_true", help="不返回界面结构树")

    for name in ("tap", "double-tap", "long-press"):
        action = sub.add_parser(name, help=f"执行 {name} 并返回新的观察结果")
        action.add_argument("x", type=_coordinate)
        action.add_argument("y", type=_coordinate)
        if name == "long-press":
            action.add_argument("--ms", type=int, default=800)
        action.add_argument("--tree", action="store_true", help="在结果中包含界面结构树")

    swipe = sub.add_parser("swipe", help="执行滑动并返回新的观察结果")
    for name in ("x1", "y1", "x2", "y2"):
        swipe.add_argument(name, type=_coordinate)
    swipe.add_argument("--ms", type=int, default=300)
    swipe.add_argument("--tree", action="store_true", help="在结果中包含界面结构树")

    type_parser = sub.add_parser("type", help="向当前输入框输入文字并返回新的观察结果")
    type_parser.add_argument("text", nargs="?", help="要输入的文字；与 --stdin 互斥")
    type_parser.add_argument("--stdin", action="store_true", help="从标准输入读取要输入的文字")
    type_parser.add_argument("--tree", action="store_true", help="在结果中包含界面结构树")

    for name in ("clear", "back", "home"):
        action = sub.add_parser(name, help=f"执行 {name} 并返回新的观察结果")
        action.add_argument("--tree", action="store_true", help="在结果中包含界面结构树")

    launch = sub.add_parser("launch", help="启动一个已知 App 或包名并返回新的观察结果")
    launch.add_argument("app")
    launch.add_argument("--tree", action="store_true", help="在结果中包含界面结构树")

    wait = sub.add_parser("wait", help="等待后返回新的观察结果，最多 10 秒")
    wait.add_argument("seconds", type=_finite_seconds)
    wait.add_argument("--tree", action="store_true", help="在结果中包含界面结构树")

    sub.add_parser("list-apps", help="列出设备上的启动器 App")

    end = sub.add_parser("end", help="保存最终截图并结束本次设备占用")
    end.add_argument("--summary", required=True, help="本次操作结果摘要")

    return parser


def _emit(payload: dict[str, Any]) -> None:
    print(json.dumps(payload, ensure_ascii=False, separators=(",", ":")))


def _default_serial() -> str:
    if not os.environ.get("OPA_PHONE_SERIAL", "").strip():
        os.environ["OPA_PHONE_SERIAL"] = DEFAULT_SERIAL
    return adb.pick_serial()


@contextlib.contextmanager
def _device_operation(task: str):
    serial = _default_serial()
    lock = DeviceLock(serial=serial, home=opa_home())
    acquired, _owner = lock.acquire(f"orbit_phone.cli:{task}")
    if not acquired:
        raise DeviceBusy
    try:
        with lock.operation() as active_serial:
            yield lock, active_serial
    finally:
        lock.release()


def _check_cancelled(lock: DeviceLock) -> None:
    if lock.is_cancelled():
        raise PhoneCancelled("Phone task was cancelled.")


def _wait(lock: DeviceLock, seconds: float) -> None:
    deadline = time.monotonic() + seconds
    while True:
        _check_cancelled(lock)
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return
        time.sleep(min(0.05, remaining))


def _timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")


def _write_screenshot(directory: Path, encoded: str) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / f"{_timestamp()}.jpg"
    path.write_bytes(base64.b64decode(encoded, validate=True))
    return path.resolve()


def _prune_shots(directory: Path) -> None:
    paths = sorted(directory.glob("*.jpg"), key=lambda p: p.stat().st_mtime_ns, reverse=True)
    for old in paths[SHOT_LIMIT:]:
        old.unlink(missing_ok=True)


def _observe(serial: str, include_tree: bool) -> tuple[dict[str, Any], dict[str, Any]]:
    info = adb.status(serial)
    screenshot = adb.screenshot(serial)
    payload: dict[str, Any] = {
        "status": "ok",
        "serial": serial,
        "foreground": info.get("foreground"),
        "screen": info.get("screen"),
        "screen_on": info.get("screen_on"),
        "locked": info.get("locked"),
        "adb_keyboard_installed": info.get("adb_keyboard_installed"),
        "is_sensitive": bool(screenshot.get("is_sensitive", False)),
    }
    if include_tree:
        payload["ui_tree"] = adb.ui_tree(serial, max_nodes=120)
    return screenshot, payload


def _observe_result(
    serial: str,
    include_tree: bool,
    *,
    action: str | None = None,
    lock: DeviceLock | None = None,
) -> dict[str, Any]:
    screenshot, payload = _observe(serial, include_tree)
    if lock is not None:
        _check_cancelled(lock)
    home = opa_home()
    screenshot_path = _write_screenshot(home / "phone" / "shots", screenshot["data"])
    _prune_shots(home / "phone" / "shots")
    result = {**payload, "screenshot": str(screenshot_path)}
    if action is not None:
        result["action"] = action
    return result


def _status() -> dict[str, Any]:
    with _device_operation("status") as (_lock, serial):
        return {"status": "ok", **adb.status(serial)}


def _observe_command(include_tree: bool) -> dict[str, Any]:
    with _device_operation("observe") as (lock, serial):
        result = _observe_result(serial, include_tree, action="observe", lock=lock)
        _check_cancelled(lock)
        return result


def _settled_action(task: str, action: Callable[[str], None], include_tree: bool) -> dict[str, Any]:
    with _device_operation(task) as (lock, serial):
        action(serial)
        _wait(lock, SETTLE_SECONDS)
        result = _observe_result(serial, include_tree, action=task.replace("-", "_"), lock=lock)
        _check_cancelled(lock)
        return result


def _wait_command(seconds: float, include_tree: bool) -> dict[str, Any]:
    with _device_operation("wait") as (lock, serial):
        _wait(lock, seconds)
        _wait(lock, SETTLE_SECONDS)
        result = _observe_result(serial, include_tree, action="wait", lock=lock)
        _check_cancelled(lock)
        return result


def _end(summary: str) -> dict[str, Any]:
    with _device_operation("end") as (lock, serial):
        screenshot = adb.screenshot(serial)
        _check_cancelled(lock)
        evidence = _write_screenshot(opa_home() / "phone" / "evidence", screenshot["data"])
        return {
            "status": "ended",
            "summary": summary,
            "screenshot": str(evidence),
            "evidence": str(evidence),
        }


def _launcher_packages(output: str) -> list[str]:
    packages: set[str] = set()
    for line in output.splitlines():
        match = _COMPONENT_RE.match(line.strip())
        if match:
            packages.add(match.group(1))
    return sorted(packages)


def _third_party_packages(output: str) -> list[str]:
    packages = set()
    for line in output.splitlines():
        value = line.strip()
        if value.startswith("package:"):
            package = value.removeprefix("package:").strip()
            if _PACKAGE_RE.fullmatch(package):
                packages.add(package)
    return sorted(packages)


def _list_apps() -> dict[str, Any]:
    with _device_operation("list-apps") as (_lock, serial):
        result = adb._run_adb(
            serial,
            "shell",
            "cmd",
            "package",
            "query-activities",
            "--brief",
            "-a",
            "android.intent.action.MAIN",
            "-c",
            "android.intent.category.LAUNCHER",
            timeout=15,
            allow_failure=True,
        )
        packages = _launcher_packages(result.stdout or "") if result.returncode == 0 else []
        if not packages:
            fallback = adb._run_adb(serial, "shell", "pm", "list", "packages", "-3", timeout=15, allow_failure=True)
            if fallback.returncode != 0:
                raise adb.AdbError("Unable to list installed Android apps.")
            packages = _third_party_packages(fallback.stdout or "")

        labels: dict[str, str] = {}
        for name, package in APP_PACKAGES.items():
            if isinstance(package, str):
                labels.setdefault(package, name)
        apps = [{"name": labels.get(package, package), "package": package} for package in packages]
        return {"status": "ok", "apps": apps}


def _run_command(args: argparse.Namespace) -> dict[str, Any]:
    command = args.command
    if command == "status":
        return _status()
    if command == "observe":
        return _observe_command(not args.no_tree)
    if command == "tap":
        return _settled_action("tap", lambda serial: adb.tap(serial, args.x, args.y), args.tree)
    if command == "double-tap":
        return _settled_action("double-tap", lambda serial: adb.double_tap(serial, args.x, args.y), args.tree)
    if command == "long-press":
        if not 1 <= args.ms <= 30_000:
            raise CliUsageError("ms 必须在 1 到 30000 之间")
        return _settled_action("long-press", lambda serial: adb.long_press(serial, args.x, args.y, args.ms), args.tree)
    if command == "swipe":
        if not 1 <= args.ms <= 30_000:
            raise CliUsageError("ms 必须在 1 到 30000 之间")
        return _settled_action("swipe", lambda serial: adb.swipe(serial, args.x1, args.y1, args.x2, args.y2, args.ms), args.tree)
    if command == "type":
        if args.stdin and args.text is not None:
            raise CliUsageError("text 与 --stdin 不能同时使用")
        if not args.stdin and args.text is None:
            raise CliUsageError("请提供 text 或使用 --stdin")
        text = sys.stdin.read() if args.stdin else args.text
        return _settled_action("type", lambda serial: adb.type_text(serial, text), args.tree)
    if command == "clear":
        return _settled_action("clear_text", adb.clear_text, args.tree)
    if command == "back":
        return _settled_action("back", adb.back, args.tree)
    if command == "home":
        return _settled_action("home", adb.home, args.tree)
    if command == "launch":
        return _settled_action("launch", lambda serial: adb.launch_app(serial, args.app), args.tree)
    if command == "wait":
        return _wait_command(args.seconds, args.tree)
    if command == "list-apps":
        return _list_apps()
    if command == "end":
        return _end(args.summary)
    raise CliUsageError("未知命令")


def _error_message(exc: BaseException) -> str:
    if isinstance(exc, CliUsageError):
        return str(exc)
    if isinstance(exc, DeviceBusy):
        return "手机正被其他任务使用，请稍后重试。"
    if isinstance(exc, PhoneNotStarted):
        return "无法取得手机设备锁。"
    if isinstance(exc, PhoneCancelled):
        return "手机操作已取消。"
    if isinstance(exc, adb.AdbError):
        return str(exc)
    return f"手机操作失败（{type(exc).__name__}）。"


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
        with contextlib.redirect_stdout(sys.stderr):
            result = _run_command(args)
    except SystemExit as exc:
        return int(exc.code or 0)
    except Exception as exc:
        _emit({"status": "error", "message": _error_message(exc)})
        return 1
    _emit(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
